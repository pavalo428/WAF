from flask import Flask, request, jsonify
import joblib
import re
import numpy as np
from scipy.sparse import hstack, csr_matrix
from datetime import datetime

app = Flask(__name__)

# Charger modèle + tfidf
model, tfidf = joblib.load("waf_prototype_model.pkl")

# ============================================
# FEATURES
# ============================================

def extract_features(req):
    return np.array([[
        len(req),
        req.count("="),
        len(re.findall(r"[<>'\";/]", req)),
        int(bool(re.search(r"SELECT|UNION|DROP|OR 1=1", req, re.I))),
        int(bool(re.search(r"<script>|onerror=", req, re.I))),
        int(bool(re.search(r"\.\./", req)))
    ]])


# ============================================
# LOGGING
# ============================================



def log_attack(req, prediction):
    with open("logs.txt", "a") as f:
        f.write(f"{datetime.now()} | {req} | {prediction}\n")



# ============================================
# ANALYSE
# ============================================



def analyze(req):
    X_text = tfidf.transform([req])
    X_manual = csr_matrix(extract_features(req))
    
    X = hstack([X_text, X_manual])
    
    proba = model.predict_proba(X)[0][1]
    
    return proba

# ============================================
# WAF
# ============================================

@app.before_request
def waf():
    
    req_data = request.path + "?" + request.query_string.decode()
    
    score = analyze(req_data)
    
    if score > 0.6:
        return jsonify({
            "message": "Requête bloquée par le WAF (attaque détectée)",
            "status": "blocked",
            "score": float(score)
        }), 403
    
    else:
        # Requête normale
        log_attack(req_data, "ALLOWED")

# ============================================
# ROUTES
# ============================================

@app.route("/")
def home():
    return "WAF actif"

@app.route("/login")
def login():
    return "Login OK"

@app.route("/search")
def search():
    return "Search OK"

# ============================================
# RUN
# ============================================

if __name__ == "__main__":
    app.run(debug=True)